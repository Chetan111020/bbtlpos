<style>
	page[size="A4"] {
		width: 21cm;
		height: 29.7cm;
	}

	page[size="A4"][layout="landscape"] {
		width: 29.7cm;
		height: 21cm;
	}

	.header {
		position: fixed;
		left: 0px;
		top: -100px;
		right: 0px;
		height: 0px;
		text-align: center;
	}

	.footer {
		position: fixed;
		left: 0px;
		bottom: -50px;
		right: 0px;
		height: 50px;
	}

	.header .pagenum:before {
		content: counter(page);
	}

	table {
		page-break-inside: auto
	}

	tr {
		page-break-inside: avoid;
		page-break-after: auto
	}

	thead {
		display: table-header-group
	}

	tfoot {
		display: table-footer-group
	}

	table {
		width: 100%;
	}

	table,
	th,
	td {
		border: 0px solid #000;
		border-collapse: collapse;
		padding: 2px;
		color: #060606 !important;
	}

	td .tdclass {
		color: #060606 !important;
	}

	p {
		color: #060606 !important;
	}

	body {
		font-family: "Poppins", sans-serif;
		font-size: 12px;
		padding: 0px;
		margin: 0px;
		line-height: 16px;
	}
</style>
<div style="padding: 15px 50px;">
	<table style="width: 100%;border: none;">
		<tr>
			<td style="border: none;">
				<table style="width: 100%;border: none">
					<tr>
						<td colspan="" style="text-align: right;vertical-align: top;border: none;">
							<table style="border: none;width:100%">
								<tr>
									<td style="border: none;width:38%;text-align: center;">
										<!-- Logo -->
										@if(!empty($receipt_details->logo))
										<img src="{{$receipt_details->logo}}" class="img img-responsive center-block">
										@endif
										<!-- Header text -->
										@if(!empty($receipt_details->header_text))
										<div class="col-xs-12" style="text-align:left;">
											{!! $receipt_details->header_text !!}
										</div>
										@endif
										<h2 style="text-transform: uppercase; margin-bottom:3px;margin-top:8px;font-size: 25px; font-weight: 600; text-align: left;color: #060606">
											<!-- Shop & Location Name  -->
											@if(!empty($receipt_details->display_name))
											{{$receipt_details->display_name}}
											@endif
										</h2>
										<p style="font-size: 13px; text-align:left;">
											@if(!empty($receipt_details->address))
											<small class="text-center">
												{!! $receipt_details->address !!}
											</small>
											@endif
											@if(!empty($receipt_details->contact))
											<br />{{ $receipt_details->contact }}
											@endif
											@if(!empty($receipt_details->contact) && !empty($receipt_details->website))
											,
											@endif
											@if(!empty($receipt_details->website))
											{{ $receipt_details->website }}
											@endif
											@if(!empty($receipt_details->location_custom_fields))
											<br>{{ $receipt_details->location_custom_fields }}
											@endif
										</p>
										<p>
											@if(!empty($receipt_details->sub_heading_line1))
											{{ $receipt_details->sub_heading_line1 }}
											@endif
											@if(!empty($receipt_details->sub_heading_line2))
											<br>{{ $receipt_details->sub_heading_line2 }}
											@endif
											@if(!empty($receipt_details->sub_heading_line3))
											<br>{{ $receipt_details->sub_heading_line3 }}
											@endif
											@if(!empty($receipt_details->sub_heading_line4))
											<br>{{ $receipt_details->sub_heading_line4 }}
											@endif
											@if(!empty($receipt_details->sub_heading_line5))
											<br>{{ $receipt_details->sub_heading_line5 }}
											@endif
										</p>
										<p>
											@if(!empty($receipt_details->tax_info1))
											<b>{{ $receipt_details->tax_label1 }}</b> {{ $receipt_details->tax_info1 }}
											@endif

											@if(!empty($receipt_details->tax_info2))
											<b>{{ $receipt_details->tax_label2 }}</b> {{ $receipt_details->tax_info2 }}
											@endif
										</p>
									</td>
									<td style="border: none;vertical-align: top;padding-left: 18px">
										<h2 style="text-transform: uppercase; margin-bottom:3px;margin-top:8px;font-size: 20px; color: #000000; font-weight: 600;">
											@if(!empty($receipt_details->invoice_heading))
											Driver Invoice
											@endif
										</h2>
										<p style="margin-left: 43%;line-height:15px;font-size:12px;text-align: left; padding-left: 26px;">
											<br>
										</p>
									</td>
								</tr>
							</table>
						</td>
						<table>
							<tr>
								<td >
									<table>
										<tr style="border: 1px solid #808080;">
											<td >
												<b style="margin-left: 3px;">{{$receipt_details->date_label}} :</b> <br>
												<SPAN style="margin-left: 3px;"> {{$receipt_details->invoice_date}} </SPAN>
											</td>
											
											<td style="border-left: 1px solid #808080;">
												<span style="margin-left: 3px;">@if(!empty($receipt_details->invoice_no_prefix))
													<b>{!! $receipt_details->invoice_no_prefix !!}</b>
													@endif <br>
													<p style="margin-left: 3px;">{{$receipt_details->invoice_no}}</p>
													@if(!empty($receipt_details->types_of_service))
													<br/>
													<span style="margin-left: 3px;" class="pull-left text-left">
														<strong>{!! $receipt_details->types_of_service_label !!}:</strong>
														{{$receipt_details->types_of_service}}
														<!-- Waiter info -->
														@if(!empty($receipt_details->types_of_service_custom_fields))
														@foreach($receipt_details->types_of_service_custom_fields as $key => $value)
														<br><strong>{{$key}}: </strong> {{$value}}
														@endforeach
														@endif
													</span>
													@endif
												</span>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</tr>
					<tr>
					</tr>
					<tr>
						<td colspan="" style="text-align: center;border:none">
							<table style="border: none;">
								<tr>
									<td style="vertical-align: top;width: 50%;border: none;padding: 5px">
										<table>

											<tr>
												<td style="vertical-align: top;padding-left: 5px;text-align: left; ">
													<!-- Table information-->
													@if(!empty($receipt_details->table_label) || !empty($receipt_details->table))

													<span class="pull-left text-left">
														@if(!empty($receipt_details->table_label))
														<b>{!! $receipt_details->table_label !!}</b>
														@endif
														{{$receipt_details->table}}
														<!-- Waiter info -->
													</span>
													@endif
													<!-- customer info -->
													@if(!empty($receipt_details->customer_name))

													<b>
														<span style="font-weight: 700; font-size: 12px;">{{ $receipt_details->customer_label }} : <br> {{ $receipt_details->customer_name }}({{$receipt_details->contact_id}}) <br></b></span>

													@endif
													<span style="color: #000;">@if(!empty($receipt_details->customer_info))
														{!! $receipt_details->customer_info !!}
														@endif
													</span>
													@if(!empty($receipt_details->client_id_label))
													<br />
													{{ $receipt_details->client_id_label }} {{ $receipt_details->client_id }}
													@endif
													@if(!empty($receipt_details->customer_tax_label))
													<br />
													{{ $receipt_details->customer_tax_label }} {{ $receipt_details->customer_tax_number }}
													@endif
													@if(!empty($receipt_details->customer_custom_fields))
													<br />{!! $receipt_details->customer_custom_fields !!}
													@endif
													@if(!empty($receipt_details->sales_person_label))
													<br />
													{{ $receipt_details->sales_person_label }} {{ $receipt_details->sales_person }}
													@endif
													@if(!empty($receipt_details->customer_rp_label))
													<br />
													<strong>{{ $receipt_details->customer_rp_label }}</strong> {{ $receipt_details->customer_total_rp }}
													@endif
													@if(!empty($receipt_details->due_date_label))
													<br><b>{{$receipt_details->due_date_label}}</b> {{$receipt_details->due_date ?? ''}}
													@endif
													@if(!empty($receipt_details->brand_label) || !empty($receipt_details->repair_brand))
													<br>
													@if(!empty($receipt_details->brand_label))
													<b>{!! $receipt_details->brand_label !!}</b>
													@endif
													{{$receipt_details->repair_brand}}
													@endif

													@if(!empty($receipt_details->device_label) || !empty($receipt_details->repair_device))
													<br>
													@if(!empty($receipt_details->device_label))
													<b>{!! $receipt_details->device_label !!}</b>
													@endif
													{{$receipt_details->repair_device}}
													@endif

													@if(!empty($receipt_details->model_no_label) || !empty($receipt_details->repair_model_no))
													<br>
													@if(!empty($receipt_details->model_no_label))
													<b>{!! $receipt_details->model_no_label !!}</b>
													@endif
													{{$receipt_details->repair_model_no}}
													@endif

													@if(!empty($receipt_details->serial_no_label) || !empty($receipt_details->repair_serial_no))
													<br>
													@if(!empty($receipt_details->serial_no_label))
													<b>{!! $receipt_details->serial_no_label !!}</b>
													@endif
													{{$receipt_details->repair_serial_no}}<br>
													@endif
													@if(!empty($receipt_details->repair_status_label) || !empty($receipt_details->repair_status))
													@if(!empty($receipt_details->repair_status_label))
													<b>{!! $receipt_details->repair_status_label !!}</b>
													@endif
													{{$receipt_details->repair_status}}<br>
													@endif

													@if(!empty($receipt_details->repair_warranty_label) || !empty($receipt_details->repair_warranty))
													@if(!empty($receipt_details->repair_warranty_label))
													<b>{!! $receipt_details->repair_warranty_label !!}</b>
													@endif
													{{$receipt_details->repair_warranty}}
													<br>
													@endif
													<!-- Waiter info -->
													@if(!empty($receipt_details->service_staff_label) || !empty($receipt_details->service_staff))
													<br />
													@if(!empty($receipt_details->service_staff_label))
													<b>{!! $receipt_details->service_staff_label !!}</b>
													@endif
													{{$receipt_details->service_staff}}
													@endif
												</td>
											</tr>
										</table>
									</td>
									<td style="width: 50%;vertical-align: top;border: none ;padding: 5px">
										<table>
											<tr>
												<td style="vertical-align: top;padding-left: 5px;text-align: left;">
													<!-- Table information-->
													@if(!empty($receipt_details->table_label) || !empty($receipt_details->table))

													<span class="pull-left text-left">
														@if(!empty($receipt_details->table_label))
														<b>{!! $receipt_details->table_label !!}</b>
														@endif
														{{$receipt_details->table}}
														<!-- Waiter info -->
													</span>
													@endif
													<!-- customer info -->
													@if(!empty($receipt_details->customer_name))
													<b>
														<span style="font-weight: 700; font-size: 12px;">Ship To : <br> {{ $receipt_details->customer_name }} <br></b></span>

													@endif
													<span style="color: #000;">@if(!empty($receipt_details->customer_info))
														{!! $receipt_details->customer_info !!}
														@endif
													</span>
													@if(!empty($receipt_details->client_id_label))
													<br />
													{{ $receipt_details->client_id_label }} {{ $receipt_details->client_id }}
													@endif
													@if(!empty($receipt_details->customer_tax_label))
													<br />
													{{ $receipt_details->customer_tax_label }} {{ $receipt_details->customer_tax_number }}
													@endif
													@if(!empty($receipt_details->customer_custom_fields))
													<br />{!! $receipt_details->customer_custom_fields !!}
													@endif
													@if(!empty($receipt_details->sales_person_label))
													<br />
													{{ $receipt_details->sales_person_label }} {{ $receipt_details->sales_person }}
													@endif
													@if(!empty($receipt_details->customer_rp_label))
													<br />
													<strong>{{ $receipt_details->customer_rp_label }}</strong> {{ $receipt_details->customer_total_rp }}
													@endif
													@if(!empty($receipt_details->due_date_label))
													<br><b>{{$receipt_details->due_date_label}}</b> {{$receipt_details->due_date ?? ''}}
													@endif
													@if(!empty($receipt_details->brand_label) || !empty($receipt_details->repair_brand))
													<br>
													@if(!empty($receipt_details->brand_label))
													<b>{!! $receipt_details->brand_label !!}</b>
													@endif
													{{$receipt_details->repair_brand}}
													@endif

													@if(!empty($receipt_details->device_label) || !empty($receipt_details->repair_device))
													<br>
													@if(!empty($receipt_details->device_label))
													<b>{!! $receipt_details->device_label !!}</b>
													@endif
													{{$receipt_details->repair_device}}
													@endif

													@if(!empty($receipt_details->model_no_label) || !empty($receipt_details->repair_model_no))
													<br>
													@if(!empty($receipt_details->model_no_label))
													<b>{!! $receipt_details->model_no_label !!}</b>
													@endif
													{{$receipt_details->repair_model_no}}
													@endif

													@if(!empty($receipt_details->serial_no_label) || !empty($receipt_details->repair_serial_no))
													<br>
													@if(!empty($receipt_details->serial_no_label))
													<b>{!! $receipt_details->serial_no_label !!}</b>
													@endif
													{{$receipt_details->repair_serial_no}}<br>
													@endif
													@if(!empty($receipt_details->repair_status_label) || !empty($receipt_details->repair_status))
													@if(!empty($receipt_details->repair_status_label))
													<b>{!! $receipt_details->repair_status_label !!}</b>
													@endif
													{{$receipt_details->repair_status}}<br>
													@endif

													@if(!empty($receipt_details->repair_warranty_label) || !empty($receipt_details->repair_warranty))
													@if(!empty($receipt_details->repair_warranty_label))
													<b>{!! $receipt_details->repair_warranty_label !!}</b>
													@endif
													{{$receipt_details->repair_warranty}}
													<br>
													@endif
													<!-- Waiter info -->
													@if(!empty($receipt_details->service_staff_label) || !empty($receipt_details->service_staff))
													<br />
													@if(!empty($receipt_details->service_staff_label))
													<b>{!! $receipt_details->service_staff_label !!}</b>
													@endif
													{{$receipt_details->service_staff}}
													@endif
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</td>
					</tr>

					<table style="width: 106%;border-top: 1px solid #808080; margin-top: 8px;">
						<tr>
							<td colspan="" style="text-align: center;border:none">
								<table style="border: none;">
									<tr>
										<td style="vertical-align: top;width: 50%;border: none;">
											<table style="">
												<tr>
													<td style="vertical-align: top;padding-left: 5px;text-align: left;">
														<span style="font-size: 16px; font-weight:300"> </span><br>

													</td>
												</tr>
											</table>
										</td>
										<td style="width: 50%;vertical-align: top;border: none; ">
											
									<tr>
										<td></td>
										<td class="text-right"></td>
										<td></td>
									</tr>
									
									<table>
										
										<tr>
											<th style="text-align: right !important;">
											
											</th>
											</td>
										</tr>
										<!-- Total Due-->
										<tr>
											<th style="text-align: right !important;">
												Open Balance
											</th>
											<td class="text-right">
											$ {!! $receipt_details->opening !!}	
											</td>
										</tr>
										<!-- Total -->
										<tr>
											<th style="text-align: right !important;">
												Order Total
											</th>
											<td class="text-right">
												{{$receipt_details->total}}
												@if(!empty($receipt_details->total_in_words))
												<br>
												<small>({{$receipt_details->total_in_words}})</small>
												@endif
											</td>
										</tr>

										<tr>
											<th style="text-align: right !important;">
												Amount Received

											</th>
											<td class="text-right">

											</td>
										</tr>

										<tr>
											<th style="text-align: right !important;">
												Balance

											</th>
											<td class="text-right">

											</td>
										</tr>
									</table>
							</td>
						</tr>
					</table>
			</td>
		</tr>
	</table>
	</table>
	<div class="row">
		@includeIf('sale_pos.receipts.partial.common_repair_invoice')
	</div>
	<table style="width: 106%;padding:2px;">
		<thead>
			<tr>
				<td style="font-weight: 700;text-align: left;vertical-align:top;border: 1px solid #808080;">
					Sr.</td>
				<td style="font-weight: 700;vertical-align:top;border: 1px solid #808080;">
					{{$receipt_details->table_product_label}}
				</td>
				<td style="font-weight: 700;text-align: left;vertical-align:top;border: 1px solid #808080;">
					{{$receipt_details->table_qty_label}}
				</td>
				<td style="font-weight: 700;text-align: left;vertical-align:top;border: 1px solid #808080;">
					{{$receipt_details->table_unit_price_label}}
				</td>
				<td style="font-weight: 700;text-align: left;vertical-align:top;border: 1px solid #808080;">
					{{$receipt_details->table_subtotal_label}}
				</td>
			</tr>
		</thead>
		<?php
		$sr = 1;
		?>
		<tbody>
			<?php
			for ($x = 0; $x <= 20; $x++) {
			?>
				<tr style="height: 25px;">
					<td style="border: 1px solid #808080;"><?php echo "$x"; ?>)</td>
					<td style="border: 1px solid #808080;"></td>
					<td style="border: 1px solid #808080;"></td>
					<td style="border: 1px solid #808080;"></td>
					<td style="border: 1px solid #808080;"></td>

				</tr>
			<?php }
			?>
		</tbody>
	</table>
	</td>

	</tr>
	</table> <br><br>
	<footer>
		<hr>
		<table style="text-align: center;">
			<tr>
				<td><b>We greatly appreciate your support and business!
						Customers are responsible for paying their Local, State & Federal Excise taxes for
						applicable products.
		</table>
	</footer>
</div>